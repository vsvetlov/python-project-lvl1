#!/usr/bin/env python3

"""Initial script."""

from brain_games.game_logic import *


def main():
    """Define main code."""
    welcome_user()
    game_even()


if __name__ == '__main__':
    main()
